README:

The code of all queries was done under the model folder, in the "DBmySql_connection" Class.